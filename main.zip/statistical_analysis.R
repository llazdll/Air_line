# ============================================================================
# Comprehensive Statistical Analysis — Airline Delay Dataset
# Includes: ANOVA, t-test, Wilcox, Clustering, Regression, Logistic Regression
# Dataset: airline_stats.csv (pct_carrier_delay, pct_atc_delay, pct_weather_delay, airline)
# ============================================================================

# Set seed globally for full reproducibility
set.seed(42)

# ----- 1. Load Libraries -----
required_packages <- c("ggplot2", "cluster", "dplyr", "tidyr", "factoextra",
                        "dunn.test", "car", "broom", "pheatmap")

install_if_missing <- function(pkg) {
  if (!requireNamespace(pkg, quietly = TRUE)) {
    install.packages(pkg, repos = "https://cloud.r-project.org/")
  }
}
lapply(required_packages, install_if_missing)

library(ggplot2)
library(cluster)
library(dplyr)
library(tidyr)
library(factoextra)
library(dunn.test)
library(car)

# ----- 2. Load Dataset -----
df <- read.csv("/Users/mohammadhosein/Desktop/amiri/airline_stats.csv", stringsAsFactors = FALSE)

cat("========== Dataset Overview ==========\n")
str(df)
cat("\nSummary:\n")
print(summary(df))
cat("\nAirlines:", paste(unique(df$airline), collapse = ", "), "\n")
cat("Total rows:", nrow(df), "\n")
cat("Missing values per column:\n")
print(colSums(is.na(df)))

# Remove rows with NA values for clean analysis
df_clean <- na.omit(df)
cat("\nRows after removing NAs:", nrow(df_clean), "\n\n")

# Convert airline to factor
df_clean$airline <- as.factor(df_clean$airline)

# ----- 3. Descriptive Plots -----
cat("========== Distribution Overview ==========\n")

# Distribution of delay types by airline
delay_long <- df_clean %>%
  pivot_longer(cols = c(pct_carrier_delay, pct_atc_delay, pct_weather_delay),
               names_to = "delay_type", values_to = "percentage") %>%
  mutate(delay_type = gsub("pct_", "", delay_type),
         delay_type = gsub("_", " ", delay_type),
         delay_type = tools::toTitleCase(delay_type))

p_dist <- ggplot(delay_long, aes(x = airline, y = percentage, fill = delay_type)) +
  geom_boxplot(alpha = 0.7, outlier.alpha = 0.1) +
  theme_minimal() +
  labs(title = "Delay Percentages by Airline and Type",
       x = "Airline", y = "Delay Percentage (%)", fill = "Delay Type") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))
print(p_dist)
ggsave("delay_distributions.png", p_dist, width = 12, height = 6)

# ----- 4. ANOVA (Analysis of Variance) -----
# Test: Does pct_carrier_delay differ across airlines?
cat("\n========== 1. One-Way ANOVA ==========\n")
cat("Testing: pct_carrier_delay ~ airline\n\n")

# ANOVA on carrier delay
anova_carrier <- aov(pct_carrier_delay ~ airline, data = df_clean)
cat("-- ANOVA: Carrier Delay ~ Airline --\n")
print(summary(anova_carrier))

# ANOVA on ATC delay
anova_atc <- aov(pct_atc_delay ~ airline, data = df_clean)
cat("\n-- ANOVA: ATC Delay ~ Airline --\n")
print(summary(anova_atc))

# ANOVA on weather delay
anova_weather <- aov(pct_weather_delay ~ airline, data = df_clean)
cat("\n-- ANOVA: Weather Delay ~ Airline --\n")
print(summary(anova_weather))

# Assumption checks (on carrier delay model)
# NOTE: ANOVA also assumes independence of observations. Flight delays may
# violate this if flights are clustered by date, route, or carrier policy.
cat("\n-- Normality of Residuals (Shapiro-Wilk) for Carrier Delay --\n")
shapiro_carrier <- shapiro.test(residuals(anova_carrier))
print(shapiro_carrier)

cat("\n-- Homogeneity of Variances (Levene's Test) for Carrier Delay --\n")
levene_result <- tryCatch({
  leveneTest(pct_carrier_delay ~ airline, data = df_clean)
}, error = function(e) {
  cat("Levene not available, using Bartlett's test instead:\n")
  bartlett.test(pct_carrier_delay ~ airline, data = df_clean)
})
print(levene_result)

# Post-hoc test: Tukey HSD
cat("\n-- Tukey HSD Post-Hoc Test (Carrier Delay) --\n")
tukey_carrier <- TukeyHSD(anova_carrier)
print(tukey_carrier)

# ANOVA boxplot
p_anova <- ggplot(df_clean, aes(x = airline, y = pct_carrier_delay, fill = airline)) +
  geom_boxplot(alpha = 0.7, outlier.alpha = 0.1) +
  geom_jitter(width = 0.1, alpha = 0.01, size = 0.3) +
  theme_minimal() +
  labs(title = "ANOVA: Carrier Delay % by Airline",
       x = "Airline", y = "Carrier Delay (%)") +
  theme(legend.position = "none", axis.text.x = element_text(angle = 45, hjust = 1))
print(p_anova)
ggsave("anova_carrier_delay.png", p_anova, width = 10, height = 6)

# ----- 5. Independent Samples t-Test -----
# Test: Is there a significant difference in carrier delay between two airlines?
cat("\n========== 2. Independent Samples t-Test ==========\n")
cat("Comparing: Delta vs United — pct_carrier_delay\n\n")

subset_du <- df_clean %>% filter(airline %in% c("Delta", "United"))

# Sample size warning
if (nrow(subset_du) < 30) {
  cat("WARNING: Small sample size for t-test. Results may be unreliable.\n")
}

# Descriptive stats
cat("-- Group Descriptives --\n")
subset_du %>%
  group_by(airline) %>%
  summarise(
    n = n(),
    mean = mean(pct_carrier_delay),
    sd = sd(pct_carrier_delay),
    median = median(pct_carrier_delay)
  ) %>%
  print()

# Check assumption: equal variance with F-test
cat("\n-- Variance F-Test --\n")
var_test <- var.test(pct_carrier_delay ~ airline, data = subset_du)
print(var_test)

# Welch's t-test (unequal variances)
t_welch <- t.test(pct_carrier_delay ~ airline, data = subset_du)
cat("\n-- Welch's t-Test ---\n")
print(t_welch)

# Pooled variance t-test
t_pooled <- t.test(pct_carrier_delay ~ airline, data = subset_du, var.equal = TRUE)
cat("\n-- Pooled Variance t-Test ---\n")
print(t_pooled)

# Effect size (Cohen's d)
cat("\n-- Cohen's d Effect Size ---\n")
cohens_d <- function(x, y) {
  pooled_sd <- sqrt(((length(x) - 1) * var(x) + (length(y) - 1) * var(y)) /
                     (length(x) + length(y) - 2))
  (mean(x) - mean(y)) / pooled_sd
}
delta_carrier <- subset_du %>% filter(airline == "Delta") %>% pull(pct_carrier_delay)
united_carrier <- subset_du %>% filter(airline == "United") %>% pull(pct_carrier_delay)
d_val <- cohens_d(delta_carrier, united_carrier)
cat("Cohen's d =", round(d_val, 4), "\n")
if (abs(d_val) < 0.2) {
  cat("Interpretation: Negligible effect\n")
} else if (abs(d_val) < 0.5) {
  cat("Interpretation: Small effect\n")
} else if (abs(d_val) < 0.8) {
  cat("Interpretation: Medium effect\n")
} else {
  cat("Interpretation: Large effect\n")
}

# t-test for all pairwise airline comparisons (bonferroni corrected)
cat("\n-- Pairwise t-Tests (all airlines, Bonferroni corrected) ---\n")
pairwise_t <- pairwise.t.test(df_clean$pct_carrier_delay, df_clean$airline,
                                p.adjust.method = "bonferroni")
print(pairwise_t)

# ----- 6. Wilcoxon Rank-Sum Test (Mann-Whitney U) -----
cat("\n========== 3. Wilcoxon Rank-Sum Test ==========\n")
cat("Comparing: Delta vs United — pct_carrier_delay (non-parametric)\n\n")

wilcox_result <- wilcox.test(pct_carrier_delay ~ airline, data = subset_du,
                              exact = FALSE, conf.int = TRUE)
print(wilcox_result)

# Effect size r = Z / sqrt(N) — computed from the Wilcoxon statistic directly
cat("\n-- Effect Size (r = Z / sqrt(N)) ---\n")
n1 <- sum(subset_du$airline == "Delta")
n2 <- sum(subset_du$airline == "United")
W <- wilcox_result$statistic
mu_W <- n1 * n2 / 2
sigma_W <- sqrt(n1 * n2 * (n1 + n2 + 1) / 12)
z_val <- (W - mu_W) / sigma_W
r_effect <- abs(z_val) / sqrt(n1 + n2)
cat("Effect size r =", round(r_effect, 4), "\n")
if (abs(r_effect) < 0.1) {
  cat("Interpretation: Negligible\n")
} else if (abs(r_effect) < 0.3) {
  cat("Interpretation: Small\n")
} else if (abs(r_effect) < 0.5) {
  cat("Interpretation: Medium\n")
} else {
  cat("Interpretation: Large\n")
}

# Kruskal-Wallis (non-parametric alternative to ANOVA)
cat("\n-- Kruskal-Wallis Test: Carrier Delay ~ Airline ---\n")
kruskal_carrier <- kruskal.test(pct_carrier_delay ~ airline, data = df_clean)
print(kruskal_carrier)

cat("\n-- Kruskal-Wallis Test: ATC Delay ~ Airline ---\n")
kruskal_atc <- kruskal.test(pct_atc_delay ~ airline, data = df_clean)
print(kruskal_atc)

# Dunn's post-hoc for Kruskal-Wallis
cat("\n-- Dunn's Post-Hoc Test (Carrier Delay, Bonferroni) ---\n")
dunn_result <- dunn.test(df_clean$pct_carrier_delay, df_clean$airline, method = "bonferroni")
print(dunn_result)

cat("\n-- Dunn's Post-Hoc Test (ATC Delay, Bonferroni) ---\n")
dunn_atc <- dunn.test(df_clean$pct_atc_delay, df_clean$airline, method = "bonferroni")
print(dunn_atc)

# Wilcoxon plot
p_wilcox <- ggplot(subset_du, aes(x = airline, y = pct_carrier_delay, fill = airline)) +
  geom_violin(alpha = 0.5) +
  geom_boxplot(width = 0.2, alpha = 0.8) +
  theme_minimal() +
  labs(title = "Wilcoxon: Carrier Delay — Delta vs United",
       x = "Airline", y = "Carrier Delay (%)") +
  theme(legend.position = "none")
print(p_wilcox)
ggsave("wilcoxon_comparison.png", p_wilcox, width = 8, height = 5)

# ----- 7. Clustering -----
cat("\n========== 4. Clustering Analysis ==========\n")
cat("Clustering airlines by: carrier, ATC, and weather delay profiles\n\n")

# Prepare features (numeric columns only)
features <- df_clean %>% select(pct_carrier_delay, pct_atc_delay, pct_weather_delay)
scaled_features <- scale(features)

# 7a. Hierarchical Clustering
cat("-- Hierarchical Clustering ---\n")
dist_matrix <- dist(scaled_features, method = "euclidean")
hc <- hclust(dist_matrix, method = "ward.D2")

# Plot dendrogram
cat("[Generating dendrogram...]\n")
p_dendro <- fviz_dend(hc, k = 6, cex = 0.3, palette = "jco",
                       rect = TRUE, rect_fill = TRUE,
                       main = "Hierarchical Clustering Dendrogram (All Flights)")
print(p_dendro)
ggsave("dendrogram.png", p_dendro, width = 12, height = 6)

# Cut tree into clusters
hc_clusters <- cutree(hc, k = 6)
cat("Cluster sizes (HC, k=6):", table(hc_clusters), "\n\n")

# 7b. Cluster airline-level profiles
cat("-- Airline-Level Clustering (mean profiles) ---\n")
airline_profiles <- df_clean %>%
  group_by(airline) %>%
  summarise(
    avg_carrier = mean(pct_carrier_delay),
    avg_atc = mean(pct_atc_delay),
    avg_weather = mean(pct_weather_delay),
    .groups = "drop"
  )
print(airline_profiles)

airline_scaled <- scale(airline_profiles[, -1])
rownames(airline_scaled) <- airline_profiles$airline

# Hierarchical clustering on airline means
hc_airline <- hclust(dist(airline_scaled, method = "euclidean"), method = "ward.D2")
cat("[Generating airline dendrogram...]\n")
p_airline_dendro <- fviz_dend(hc_airline, cex = 0.8, palette = "jco",
                               rect = TRUE, rect_fill = TRUE,
                               main = "Hierarchical Clustering — Airline Delay Profiles")
print(p_airline_dendro)
ggsave("airline_dendrogram.png", p_airline_dendro, width = 8, height = 5)

# K-Means on airline profiles
cat("\n-- K-Means Clustering (airline profiles) ---\n")

# Elbow method
cat("[Generating elbow plot...]\n")
p_elbow <- fviz_nbclust(airline_scaled, kmeans, method = "wss", k.max = 5) +
  labs(title = "Optimal Clusters — Elbow Method (Airlines)")
print(p_elbow)
ggsave("elbow_plot.png", p_elbow, width = 7, height = 5)

# Silhouette method
cat("[Generating silhouette plot...]\n")
p_sil <- fviz_nbclust(airline_scaled, kmeans, method = "silhouette", k.max = 5) +
  labs(title = "Optimal Clusters — Silhouette Method (Airlines)")
print(p_sil)
ggsave("silhouette_plot.png", p_sil, width = 7, height = 5)

# Run k-means on airline profiles — safely choose k < number of airlines
k <- min(3, nrow(airline_scaled) - 1)
set.seed(42)
km_airline <- kmeans(airline_scaled, centers = k, nstart = 25)
cat("K-Means Cluster assignments:\n")
airline_cluster_df <- data.frame(
  Airline = airline_profiles$airline,
  Cluster = km_airline$cluster
)
print(airline_cluster_df)
cat("\nCluster centers (standardized):\n")
print(round(km_airline$centers, 4))
cat("Between-SS / Total-SS:", round(km_airline$betweenss / km_airline$totss * 100, 2), "%\n")

# Visualize k-means — add labels using the cluster centers data frame
cat("[Generating k-means cluster plot...]\n")
km_coords <- as.data.frame(km_airline$centers)
km_coords$Airline <- rownames(km_airline$centers)

p_km <- fviz_cluster(km_airline, data = airline_scaled,
                      palette = "jco", ggtheme = theme_minimal(),
                      main = "K-Means Clustering — Airline Delay Profiles") +
  geom_text(data = km_coords,
            aes(x = pct_carrier_delay, y = pct_atc_delay, label = Airline),
            vjust = -0.8, size = 3.5, color = "black", fontface = "bold")
print(p_km)
ggsave("kmeans_airlines.png", p_km, width = 8, height = 6)

# K-Means on individual flights (sample for speed)
cat("\n-- K-Means on Flight-Level Data (sample of 5000) ---\n")
set.seed(123)
sample_idx <- sample(nrow(scaled_features), min(5000, nrow(scaled_features)))
sample_features <- scaled_features[sample_idx, ]

set.seed(42)
km_flights <- kmeans(sample_features, centers = 6, nstart = 25)
cat("Flight cluster sizes:", table(km_flights$cluster), "\n")
cat("Between-SS / Total-SS:", round(km_flights$betweenss / km_flights$totss * 100, 2), "%\n")

# Cluster profile — show the dominant airline per cluster instead of first()
sample_df <- df_clean[sample_idx, ]
sample_df$cluster <- km_flights$cluster
cluster_summary <- sample_df %>%
  group_by(cluster) %>%
  summarise(
    top_airline = names(sort(table(airline), decreasing = TRUE))[1],
    pct_top_airline = round(max(table(airline)) / n() * 100, 1),
    avg_carrier = mean(pct_carrier_delay),
    avg_atc = mean(pct_atc_delay),
    avg_weather = mean(pct_weather_delay),
    n = n(),
    .groups = "drop"
  ) %>%
  arrange(cluster)
cat("\nCluster profiles (individual flights):\n")
print(cluster_summary)

p_km_flights <- fviz_cluster(km_flights, data = sample_features,
                              choose.vars = c(1, 2),
                              palette = "jco", ggtheme = theme_minimal(),
                              main = "K-Means — Flight Delay Profiles (sample)")
print(p_km_flights)
ggsave("kmeans_flights.png", p_km_flights, width = 8, height = 6)

# Heatmap of airline profiles
cat("\n[Generating airline profile heatmap...]\n")
p_heatmap <- ggplot(
  tidyr::pivot_longer(airline_profiles, -airline, names_to = "delay_type", values_to = "percentage"),
  aes(x = delay_type, y = airline, fill = percentage)
) +
  geom_tile() +
  geom_text(aes(label = round(percentage, 1)), color = "white", size = 4) +
  scale_fill_gradient(low = "#2c7bb6", high = "#d7191c") +
  theme_minimal() +
  labs(title = "Average Delay Percentages by Airline and Type",
       x = "Delay Type", y = "Airline", fill = "Avg %")
print(p_heatmap)
ggsave("airline_heatmap.png", p_heatmap, width = 8, height = 5)

# ----- 8. Linear Regression -----
cat("\n========== 5. Linear Regression ==========\n")
cat("Predicting pct_carrier_delay from ATC and weather delays\n\n")

# Simple Linear Regression
cat("-- Simple: Carrier Delay ~ ATC Delay ---\n")
lm_simple <- lm(pct_carrier_delay ~ pct_atc_delay, data = df_clean)
print(summary(lm_simple))

# Multiple Linear Regression
cat("\n-- Multiple: Carrier Delay ~ ATC Delay + Weather Delay ---\n")
lm_multi <- lm(pct_carrier_delay ~ pct_atc_delay + pct_weather_delay, data = df_clean)
print(summary(lm_multi))

# With airline as predictor
cat("\n-- Multiple: Carrier Delay ~ ATC Delay + Weather Delay + Airline ---\n")
lm_airline <- lm(pct_carrier_delay ~ pct_atc_delay + pct_weather_delay + airline, data = df_clean)
print(summary(lm_airline))

# Interaction model
cat("\n-- Interaction: Carrier Delay ~ ATC Delay * Airline ---\n")
lm_interact <- lm(pct_carrier_delay ~ pct_atc_delay * airline, data = df_clean)
print(summary(lm_interact))

# Model comparison using AIC
cat("\n-- Model Comparison (AIC) ---\n")
models <- c("Simple" = AIC(lm_simple),
            "Multi" = AIC(lm_multi),
            "Airline" = AIC(lm_airline),
            "Interaction" = AIC(lm_interact))
cat("AIC values:\n")
print(round(models, 2))
cat("\nBest model:", names(which.min(models)), "(lowest AIC)\n")

# Diagnostic plots for best model
cat("\n[Generating regression diagnostic plots...]\n")
png("regression_diagnostics.png", width = 1200, height = 900)
par(mfrow = c(2, 2))
plot(lm_multi)
dev.off()
cat("Saved: regression_diagnostics.png\n")

# VIF (Multicollinearity check)
cat("\n-- Variance Inflation Factors ---\n")
vif_result <- tryCatch({
  vif(lm_multi)
}, error = function(e) {
  cat("VIF computation failed:", conditionMessage(e), "\n")
  NULL
})
if (!is.null(vif_result)) {
  print(vif_result)
  if (any(vif_result > 5)) {
    cat("WARNING: VIF > 5 suggests moderate-to-high multicollinearity.\n")
  } else {
    cat("All VIF values < 5 — multicollinearity is acceptable.\n")
  }
}

# Bland visualization
cat("[Generating regression scatterplot...]\n")
p_reg <- ggplot(df_clean[sample(nrow(df_clean), min(5000, nrow(df_clean))), ],
                aes(x = pct_atc_delay, y = pct_carrier_delay, color = airline)) +
  geom_point(alpha = 0.2, size = 0.5) +
  geom_smooth(method = "lm", se = TRUE, color = "black", linetype = "dashed") +
  geom_smooth(method = "lm", se = FALSE, linewidth = 0.8) +
  theme_minimal() +
  labs(title = "Linear Regression: Carrier Delay vs ATC Delay by Airline",
       x = "ATC Delay (%)", y = "Carrier Delay (%)", color = "Airline")
print(p_reg)
ggsave("regression_plot.png", p_reg, width = 10, height = 6)

# ----- 9. Logistic Regression -----
cat("\n========== 6. Logistic Regression ==========\n")
cat("Predicting airline membership (binary) from delay profile\n\n")

# Create binary outcome: largest airline vs. all others
# Auto-select the airline with the most flights to ensure both classes exist
target_airline <- names(sort(table(df_clean$airline), decreasing = TRUE))[1]
cat("Binary target:", target_airline, "vs. not", target_airline, "\n\n")

df_clean$is_target <- ifelse(df_clean$airline == target_airline, 1, 0)
df_clean$is_target <- factor(df_clean$is_target,
                              levels = c(0, 1),
                              labels = c(paste0("Not_", target_airline), target_airline))

# Balance check
cat("Class distribution:\n")
print(table(df_clean$is_target))

# Binary Logistic Regression
cat("\n-- Logistic Regression: P(", target_airline, ") ~ all delay types --\n")
glm_binary <- glm(is_target ~ pct_carrier_delay + pct_atc_delay + pct_weather_delay,
                  data = df_clean, family = binomial(link = "logit"))
print(summary(glm_binary))

# Check for complete separation (coefficients blowing up)
if (any(abs(coef(glm_binary)) > 10)) {
  cat("\nWARNING: Large coefficients detected — possible complete separation.\n")
  cat("Consider using Firth's penalized likelihood (package 'logistf').\n\n")
}

# Odds ratios
cat("\n-- Odds Ratios ---\n")
odds_ratios <- exp(coef(glm_binary))
cat("Coefficients as Odds Ratios:\n")
print(round(odds_ratios, 4))

# Confidence intervals for odds ratios
cat("\n-- 95% CI for Odds Ratios ---\n")
ci_or <- exp(confint(glm_binary))
print(round(ci_or, 4))

# Model fit statistics
cat("\n-- Model Fit ---\n")
cat("Null deviance:", glm_binary$null.deviance, "on", glm_binary$df.null, "df\n")
cat("Residual deviance:", glm_binary$deviance, "on", glm_binary$df.residual, "df\n")
cat("AIC:", AIC(glm_binary), "\n")

# Hosmer-Lemeshow goodness of fit
cat("\n-- Hosmer-Lemeshow Goodness of Fit Test ---\n")
hl_test <- function(model, g = 10) {
  y <- model$y
  yhat <- model$fitted.values
  cutyhat <- cut(yhat, breaks = quantile(yhat, probs = seq(0, 1, 1/g)), include.lowest = TRUE)
  obs <- xtabs(~ cutyhat + y)
  Expected_1 <- as.numeric(tapply(yhat, cutyhat, sum))
  Expected_0 <- as.numeric(tapply(1 - yhat, cutyhat, sum))

  # Guard against division by zero from sparse groups
  if (any(Expected_0 == 0) || any(Expected_1 == 0)) {
    cat("Warning: Some expected counts are zero. Reducing groups.\n")
    if (g <= 3) {
      cat("Cannot reduce groups further. Skipping HL test.\n")
      return(invisible(NULL))
    }
    return(hl_test(model, g = g - 1))
  }

  HLstat <- sum((obs[, 1] - Expected_0)^2 / Expected_0 + (obs[, 2] - Expected_1)^2 / Expected_1)
  pvalue <- pchisq(HLstat, g - 2, lower.tail = FALSE)
  cat("Hosmer-Lemeshow Chi-sq =", round(HLstat, 4),
      ", df =", g - 2, ", p-value =", round(pvalue, 4), "\n")
  cat("p > 0.05:", pvalue > 0.05, "(TRUE = good fit)\n")
}
hl_test(glm_binary)

# Predictions and classification table (use sample for speed)
cat("\n-- Classification Table (threshold = 0.5) ---\n")
predicted_prob <- predict(glm_binary, type = "response")
predicted_class <- factor(ifelse(predicted_prob > 0.5, target_airline, paste0("Not_", target_airline)),
                           levels = c(paste0("Not_", target_airline), target_airline))

conf_matrix <- table(Predicted = predicted_class, Actual = df_clean$is_target)
print(conf_matrix)

accuracy <- sum(diag(conf_matrix)) / sum(conf_matrix)
sensitivity <- conf_matrix[2, 2] / sum(conf_matrix[, 2])
specificity <- conf_matrix[1, 1] / sum(conf_matrix[, 1])
ppv <- conf_matrix[2, 2] / sum(conf_matrix[2, ])
npv <- conf_matrix[1, 1] / sum(conf_matrix[1, ])

cat("\nPerformance Metrics:\n")
cat("  Accuracy:    ", round(accuracy * 100, 2), "%\n")
cat("  Sensitivity: ", round(sensitivity * 100, 2), "%\n")
cat("  Specificity: ", round(specificity * 100, 2), "%\n")
cat("  PPV (Prec.): ", round(ppv * 100, 2), "%\n")
cat("  NPV:         ", round(npv * 100, 2), "%\n")

# ROC Curve (manual implementation)
cat("\n-- ROC Analysis ---\n")
roc_data <- data.frame(
  actual = as.numeric(df_clean$is_target == target_airline),
  predicted_prob = predicted_prob
)
# Sort by descending probability to compute TPR/FPR at each threshold
roc_data <- roc_data[order(-roc_data$predicted_prob), ]
roc_data$tpr <- cumsum(roc_data$actual) / sum(roc_data$actual)
roc_data$fpr <- cumsum(1 - roc_data$actual) / sum(1 - roc_data$actual)

# Sort by ascending FPR for correct trapezoidal integration
roc_data <- roc_data[order(roc_data$fpr), ]
auc <- sum(diff(roc_data$fpr) * (head(roc_data$tpr, -1) + tail(roc_data$tpr, -1)) / 2)
auc <- abs(auc)
cat("AUC:", round(auc, 4), "\n")

p_roc <- ggplot(roc_data %>% slice_sample(n = min(500, nrow(roc_data))), aes(x = fpr, y = tpr)) +
  geom_line(color = "blue", linewidth = 1) +
  geom_abline(slope = 1, intercept = 0, linetype = "dashed", color = "gray") +
  theme_minimal() +
  labs(title = paste("ROC Curve —", target_airline, "vs Others (AUC =", round(auc, 4), ")"),
       x = "False Positive Rate (1 - Specificity)",
       y = "True Positive Rate (Sensitivity)") +
  coord_equal() +
  xlim(0, 1) + ylim(0, 1)
print(p_roc)
ggsave("roc_curve.png", p_roc, width = 7, height = 7)

# Visualize logistic regression probability
cat("\n[Generating logistic regression probability curve...]\n")
df_plot <- df_clean[sample(nrow(df_clean), min(5000, nrow(df_clean))), ]
df_plot$prob_target <- predict(glm_binary, newdata = df_plot, type = "response")

p_logistic <- ggplot(df_plot, aes(x = pct_atc_delay, y = as.numeric(is_target) - 1)) +
  geom_point(alpha = 0.15, size = 0.5,
             position = position_jitter(height = 0.05)) +
  geom_line(aes(y = prob_target, group = 1), color = "red", linewidth = 1) +
  theme_minimal() +
  labs(title = paste("Logistic Regression: P(", target_airline, ") vs ATC Delay"),
       x = "ATC Delay (%)", y = paste("Probability of", target_airline))
print(p_logistic)
ggsave("logistic_regression_plot.png", p_logistic, width = 8, height = 5)

# ============================================================================
# Final Summary
# ============================================================================
cat("\n")
cat("================================================\n")
cat("           ANALYSIS COMPLETE                    \n")
cat("================================================\n")
cat("\nGenerated output files:\n")
cat("  1.  delay_distributions.png     — Delay type boxplots by airline\n")
cat("  2.  anova_carrier_delay.png     — ANOVA boxplot\n")
cat("  3.  wilcoxon_comparison.png     — Wilcoxon violin+boxplot\n")
cat("  4.  dendrogram.png              — Hierarchical clustering (flights)\n")
cat("  5.  airline_dendrogram.png      — Hierarchical clustering (airlines)\n")
cat("  6.  elbow_plot.png              — Elbow method\n")
cat("  7.  silhouette_plot.png         — Silhouette method\n")
cat("  8.  kmeans_airlines.png         — K-means (airline profiles)\n")
cat("  9.  kmeans_flights.png          — K-means (flight-level sample)\n")
cat("  10. airline_heatmap.png         — Airline delay heatmap\n")
cat("  11. regression_diagnostics.png  — LM diagnostics (4-panel)\n")
cat("  12. regression_plot.png         — Regression scatterplot\n")
cat("  13. logistic_regression_plot.png— Logistic probability curve\n")
cat("  14. roc_curve.png               — ROC curve with AUC\n")
cat("================================================\n")
